---- last review: 2021/06/23 ----

1. How to use the local version of the tool: 
- open index.html inside: \Agile Tags--Offline Version\01 Agile Tags App\index.html

2. BUGS
If a bug appear try to open the app in the Browse in private mode (to purge the localstorage)


3. Clone a Form.
To clone a questionnaire you only need to access the following URLs and copy the template. Once this is done you can start collecting user responses

Keep in mind that if you modify the form you will also have to modify the validator for the tool to work correctly.

// Forms List:

--PRODUCT OWNER:
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy2-CO6K_ORz1Hp4GXjAMlQbJUN1cxS0k2WVVXUUFETDlZODhMQkNORE5PNC4u&sharetoken=bvTBNEBVopotwXFdrEjk

--SCRUM MASTER: 
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy2-CO6K_ORz1Hp4GXjAMlQbJUMERWSzhLUEg2QTBaMVJMWkMwMTFGS0xCUS4u&sharetoken=hb8wINznwfccmNgWLAlU

--TRIBE LEAD: 
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy21DMLhy5nJJIuySOeE0SUB9URDNHMzk5MzJIUjhCVE5KWDRQWlJQMDZYOC4u&sharetoken=Jp2e0Oo4JpiivEXHNOQq

--TRIBE TECHNOLOGY LEAD
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy2-CO6K_ORz1Hp4GXjAMlQbJUNkhQS0lPQlAzT0FXWVBBRFI3Mzg4TkRIVC4u&sharetoken=6CA9XswPeMLyeyhelUwW

--RELEASE TRAIN ENGINEER
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy2-CO6K_ORz1Hp4GXjAMlQbJUM0tCOVVIQ0FMWlY2Skk1M1E2ODJQSVUxMS4u&sharetoken=6xFHdwI0HJ3JmwJ1ajco

--PRODUCT MANAGER 
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy2-CO6K_ORz1Hp4GXjAMlQbJUNjhJV1NJUkpXT0pGOUwxMkFSS0dTQVdSUS4u&sharetoken=vGdQ90iaGoDyFpwP8NKj

--SOFTWARE ENGINEER
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy27LjSuVSjx9Goc_wIX7GZClUM1E2OU5TNFY4RU1HTFFXRzdaTEhVOUZCMi4u&sharetoken=j2z8IrEEC1h0xBjIMMVc

--SOLUTION ARCHITECT
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy21DMLhy5nJJIuySOeE0SUB9UNUJFTzFYVUk1VDNUTUxWSEczQlRXTDNSRS4u&sharetoken=ZW0udYDxHbq0eQtN7bUL

--DEVOPS
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy27LjSuVSjx9Goc_wIX7GZClUNEdSUEw3OUROQUlDT0pCN0FSMTFPNzg5Qy4u&sharetoken=szzv8MilRIkF0Gk2QHp8

--TESTING ENGINEER
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy27LjSuVSjx9Goc_wIX7GZClUN09WVDhJRFNQSkgyUFU5SEcwVFM4T1Y3NC4u&sharetoken=xAzAwiqr0DlT9CluJzIm

--CHAPTER LEAD
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy27LjSuVSjx9Goc_wIX7GZClUQUk5SlQxMEYyOUZTT0VIUFlXUjU4RVFKUy4u&sharetoken=bnlNDyTQfpedBrUfJpVr

--AGILE COACH 
https://forms.office.com/Pages/ShareFormPage.aspx?id=AlpZNW1NrESZ4fmrTNhy27LjSuVSjx9Goc_wIX7GZClUNFBGS0hKTjVOS0FDSzhHVjVPT1RFS1BLMi4u&sharetoken=Op8m8u34GXBupu7ech7T




