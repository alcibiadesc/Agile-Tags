import { writable } from 'svelte/store';

export const dataLevel = writable([]);

export const dataAxis = writable([]);