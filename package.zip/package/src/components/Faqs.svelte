<style>
	article {
		background-color: white;
		z-index: 3;
	}
	p {
		text-align: left;
	}

	li {
		text-align: left;
	}

	ol {
		text-align: left;
	}
</style>

<article class=" bba b--black-05 mb6 pa3 bg-white">
	<h2>¿Qué campos son obligatorios tener en el excel y con que formato?</h2>
	<p>
		Los únicos campos obligatorios que deben figurar
		<strong>literalmente</strong>
		de la siguiente forma encabezando una columna del excel son:
		<strong>Tribu, Nombre y Correo electrónico.</strong>
	</p>
	<h2 class="mt4">¿Cuál es el formato del excel?</h2>
	<p>
		<strong>IMPORTANTE</strong>, el excel sólo debe tener una hoja (salvo que
		sea un formulario ya moderado), para evitar problemas a la hora de cargarlo.
		En la primera fila se encontrarán los enunciados de las preguntas. Cada fila
		será interpretada como la respuesta de una persona.
	</p>
	<h2 class="mt4">
		¿Cuál es el formato de la Plantilla para corregir el formulario?
	</h2>
	<p>
		Cada pregunta debe ir precedida por un código compuesto de los siguientes
		elementos (A-1-2-3)
		<br />
		La letra A hace referencia al eje de conocimiento correspondiente para cada
		agrupación en orden secuencial al cuestionario, así, por ejemplo para:
	</p>
	<ul>
		<li>Product Management = A.</li>
		<li>Customer and Stakeholder Mng. = B.</li>
		<li>Product Delivery = C.</li>
		<li>Relationship with the team = D.</li>
	</ul>

	<p>
		El primer número que aparece, en el ejemplo el 1, corresponde con el nivel
		de madurez de la pregunta, existiendo los tres niveles que todos conocemos:<br />
	</p>
	<ul>
		<li>Participant = 1</li>
		<li>Practitioner = 2</li>
		<li>Expert = 3</li>
	</ul>
	<p>
		El segundo número que aparece en el ejemplo (A-1-2), el "2" corresponde al
		orden secuencial de las preguntas, en este caso haría referencia a la
		segunda pregunta del Bloque A del nivel 1.<p>Este es reseteado al subir un nivel, por ejemplo de A-1-3-3 saltaríamos al siguiente bloque B-1-1-1</p>
	<p>
		<strong>IMPORTANTE!</strong>
		debemos mantener la agrupación del validador, existiendo por ejemplo grupos
		de 3 preguntas juntos (Si/No + Texto Libre + pregunta sobre cuanto tiempo
		lleva haciéndolo).
	</p>
	<p>
		El último número del código (A-1-2-3) el "3" hace referencia a la posición
		de esa pregunta dentro del grupo de preguntas, siendo en este caso una
		pregunta del Bloque A, nivel 1, grupo 2 y 3 pregunta.
	</p>
	<p>
		Aunque pueda parecer complejo, básicamente se trata de añadir por orden
		secuencial el código de texto que corresponda en cada pregunta. Por ejemplo:
	</p>
	<ol>
		<li>A-1-1-1 ¿Cuanto debe durar una Daily Scrum?</li>
		<li>A-1-1-2 ¿Técnicas que utilices para facilitar la Daily?</li>
		<li>A-1-1-3 ¿Desde cuando las utilizas?</li>
	</ol>
		<p>
			Asimismo, hay 2 preguntas obligatorias que van sin código: Nombre y Tribu
			(tal y como aparecen con la primera letra en mayúscula) y una opcional,
			que sería Rol.
		</p>
		<h2 class="mt4">¿Cómo puedo importar un excel?</h2>
		<p>
			Haz click en el apartado seleccionar fichero y automaticamente se
			procederá a la importanción y procesamiento del documento.
		</p>

		<h2 class="mt4">Me he equivocado de excel, ¿que puedo hacer?</h2>
		<p>
			Haz click en el botón "resetear" de la barra superior derecha o, en su
			defecto, abre una nueva ventana de incognito. Otra opción, para usuarios
			avanzados, es borrar el localStorage donde se almacena el excel erroneo de
			tu navegador relativo a esta web.
		</p>
</article>
