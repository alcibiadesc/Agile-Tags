export const backgroundColor = [
	"rgb(255, 177, 193, 0.8)",
	"rgb(255, 207, 161, 0.8)",
	"rgb(166, 223, 223, 0.8)",
	"rgb(156, 208, 245, 0.8)",
	"rgb(255, 230, 172, 0.8)",
];

export const borderColor = [];

export const borderWidth = 1;
