<script>
	import { Polar, Vertical } from "./Charts";
</script>

<style>
	.centered {
		margin-right: auto;
		margin-left: auto;
	}
</style>

<div class="cf centered w-80">
	<div class="fl w-50 bg-white">
		<Vertical />
	</div>
	<div class="fr w-50 bg-white ">
		<Polar />
	</div>
</div>
