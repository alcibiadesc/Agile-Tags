<script>
    let yearNow = new Date().getFullYear();
</script>

<style>
    footer {
        bottom: 0;
    }
</style>

<footer class="pv4 ph3 ph5-m ph6-l mid-gray mt6">
    <small class="f6 db tc">©
        {yearNow}
				<!--  <b class="ttu">Santander Global Tech</b> -->., All Rights Reserved</small>
    <div class="tc f6 db ">
        <p>
            La información procesada no es trasferida a ningún servidor externo.
            Siendo utilizada y procesada en el equipo local del usuario a través
            de su navegador web. No recopilando ningún tipo de información en el
            proceso
        </p>
    </div>
</footer>
