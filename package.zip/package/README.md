# Agile-Flags

This is an internal project of the CoE Agile of Santander Global Tech. 
Our purpose is study Agile mindset maturity levels 
